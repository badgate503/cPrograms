#ifndef __SAVE_H
#define __SAVE_H

#include "genlib.h"
#include "tangramMain.h"
#include "makeShape.h"
#include "finalPattern.h" 
#include "linkedlist.h"

void File_in();
void loadGame(string pathG);
void putVec(void *v);
#endif 
