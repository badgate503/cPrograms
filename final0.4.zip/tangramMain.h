#ifndef __TANGRAMMAIN_H__
#define __TANGRAMMAIN_H__

#include "genlib.h"
#include "tangramMain.h"
#include "Save.h"

#define BOUND_WIDTH 0.5
#define BTN_NUM 5
#define BTN_NUM_UI 6
#define GAME_NUM 2

#endif 

